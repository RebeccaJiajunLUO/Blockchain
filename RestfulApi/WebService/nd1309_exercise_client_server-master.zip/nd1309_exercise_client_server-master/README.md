# Client-Server Exercise with Node.js

In this exercise you will practice a creation of a web service that respond with the block hash.

## Steps to follow

1. Clone the repository to your local computer.
2. Open the terminal and install the packages: `npm install`.
3. Open the file `app.js` and start coding.
4. Run your application `node app.js`
5. Go to yur browser and type: `http://localhost:8080/`
6. Get the hash generated in your browser and answer the quiz in your classroom.




